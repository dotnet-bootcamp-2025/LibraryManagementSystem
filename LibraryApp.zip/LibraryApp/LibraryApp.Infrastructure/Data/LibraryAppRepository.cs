﻿using LibraryApp.Application.Abstractions;
using LibraryApp.Domain.Entities;

namespace LibraryApp.Infrastructure.Data
{
    public class LibraryAppRepository : ILibraryAppRepository
    {
        private readonly AppDbContext _context;
        public LibraryAppRepository(AppDbContext context)
        {
            _context = context;
        }

        public void AddLibraryItem(LibraryItems libraryItem) 
        {
            _context.LibraryItems.Add(libraryItem);
            _context.SaveChanges();
        }

        public IEnumerable<LibraryItems> GetAllLibraryItems()
        {
            return _context.LibraryItems.ToList();
        }

        public LibraryItems? GetLibraryItemById(int id)
        {
            return _context.LibraryItems.Find(id);

            //var x = _context.LibraryItems.Where(li => li.IsBorrowed && li.Pages > 100).First();
            //return x; esto nos da todos los libros prestados con mas de 100 paginas, pero me da el primero que encuentra
            //lo podemos usar para encontrar por nombre
        }

        public void UpdateLibraryItem(LibraryItems libraryitem)
        {
            _context.LibraryItems.Update(libraryitem);
            _context.SaveChanges();
        }
        public Member? GetMemberById(int id)
        {
            return _context.Member.Find(id);
        }

        public void AddBorrowItem(BorrowedItem borrowedItem)
        {
            _context.BorrowedItems.Add(borrowedItem);
            _context.SaveChanges();
        }

        public IEnumerable<Member> GetAllMembers()
        {
            return _context.Member.ToList();
        }
    }
}

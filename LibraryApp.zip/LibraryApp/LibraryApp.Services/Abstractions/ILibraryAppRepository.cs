﻿
using LibraryApp.Domain.Entities;

namespace LibraryApp.Application.Abstractions
{
    public interface ILibraryAppRepository
    {
        IEnumerable<LibraryItems> GetAllLibraryItems();
        IEnumerable<Member> GetAllMembers();
        void AddLibraryItem(LibraryItems libraryItem);
        void UpdateLibraryItem(LibraryItems item);

        LibraryItems? GetLibraryItemById(int id);

        Member? GetMemberById(int id);

        void AddBorrowItem(BorrowedItem borrowedItem);
    }
}

﻿namespace LibraryApp.Api.Records
{

    public record BorrowRecord(int memberId, int itemId) { }

}

//revisar con Miguel en la sesion de dudas

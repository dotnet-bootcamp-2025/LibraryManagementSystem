﻿namespace LibraryApp.Api.Records
{
    public class MemberRecord
    {
        public record CreateMemberRequest(string Name) { }
    }
}

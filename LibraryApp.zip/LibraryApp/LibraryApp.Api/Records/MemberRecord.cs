﻿namespace LibraryApp.Api.Records
{

        public record AddMemberRecord(string Name) { }
    
}

﻿namespace LibraryApp.Api.Records
{
    public record ReturnRecord(int memberId, int itemId) { }
}

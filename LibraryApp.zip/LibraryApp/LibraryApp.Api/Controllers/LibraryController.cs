﻿using LibraryApp.Api.Records;
using LibraryApp.Application.Abstractions;
using LibraryApp.Domain;
using Microsoft.AspNetCore.Mvc;
using static LibraryApp.Api.Records.BookRecord;
using static LibraryApp.Api.Records.MagazineRecord;
using static LibraryApp.Api.Records.MemberRecord;
using static LibraryApp.Api.Records.BorrowRecord;

namespace LibraryApp.Api.Controllers
{
    public partial class LibraryController : ControllerBase
    {
        private readonly ILibraryService _service;

        public LibraryController(ILibraryService libraryservice)
        {
            _service = libraryservice;
        }

        [HttpGet("items")]
        public IActionResult GetItems()
        {
            var items = _service.GetAllLibraryItems();
            Console.WriteLine($"GET - Service instance: {_service.GetHashCode()}, Items count: {items.Count()}"); 

            return Ok(items);


        }

        // Get all registered members
        [HttpGet("members")]
        public IActionResult ListMembers()
        {
            Console.WriteLine($"GET - Service instance: {_service.GetHashCode()}, List Members:");
            var members = _service.GetAllMembers();
            return Ok(members);
        }

        //add POST to add a new book
        [HttpPost("Add Book")]
        public IActionResult AddBook([FromBody] CreateBookRequest Book)
        {
            if (Book == null || string.IsNullOrWhiteSpace(Book.Title) || string.IsNullOrWhiteSpace(Book.Author))
            {
                return BadRequest("Invalid book data.");
            }

            var addedBook = _service.AddBook(Book.Title, Book.Author, Book.Pages);
            return CreatedAtAction(nameof(GetItems), new { id = addedBook.Id }, addedBook);
        }

        [HttpPost("Borrow")]

        public IActionResult BorrowItem([FromBody] BorrowRecord borrow)
        {
            if (borrow == null || borrow.memberId <= 0 || borrow.itemId <= 0)
            {
                return BadRequest("Invalid member or item ID.");
            }
            var ok = _service.BorrowItem(borrow.memberId, borrow.itemId, out string message);
            Console.WriteLine($"POST - Borrow Item succesfully. MemberId={borrow.memberId}, ItemId={borrow.itemId}");
            if (ok) return Ok(new {success = ok, message = message});
            return BadRequest(new { success = ok, message = message });
        }


    }
}

//        [HttpPost("Magazine")]
//        public IActionResult AddMagazine([FromBody] CreateMagazineRequest Magazine)
//        {
//            if (Magazine == null || string.IsNullOrWhiteSpace(Magazine.Title) || string.IsNullOrWhiteSpace(Magazine.Publisher))
//            {
//                return BadRequest("Invalid Magazine data.");
//            }

//            var addedMagazine = _service.AddMagazine(Magazine.Title, Magazine.IssueNumber, Magazine.Publisher);
//            return CreatedAtAction(nameof(GetItems), new { id = addedMagazine.Id }, addedMagazine);
//        }

//        [HttpPost("Member")]
//        public IActionResult RegisterMember([FromBody] CreateMemberRequest Member)
//        {
//            if (Member == null || string.IsNullOrWhiteSpace(Member.Name) || string.IsNullOrWhiteSpace(Member.Name))
//            {
//                return BadRequest("Invalid Magazine data.");
//            }

//            var member = _service.RegisterMember(Member.Name);
//            return CreatedAtAction(nameof(GetItems), new { name = Member.Name });
//        }



//        [HttpPost("Return")]
//        public IActionResult ReturnItem(int memberId, int itemId)
//        {
//            if (memberId <= 0 || itemId <= 0)
//            {
//                return BadRequest("Invalid member or item ID.");
//            }
//            if (_service.ReturnItem(memberId, itemId, out string message))
//            {
//                return Ok("Item returned successfully.");
//            }
//            else
//            {
//                return BadRequest(message);
//            }
//        }

//        [HttpGet("Find Item")]
//        public IActionResult FindItems(string? term)
//        {

//            var items = _service.FindItems(term);
//            return Ok(items);
//        }

//        //TODO: add POST to add a new magazine, members, borrowing, and returning items


//    }
//}

﻿// enum para definir los tipos de items en la biblioteca
namespace LibraryApp.Domain.Enums
{
    public enum LibraryItemTypeEnum
    {
        Book = 1,
        Magazine = 2
    }
}
